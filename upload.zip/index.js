'use strict'

exports.handler = (event,context,callback) => {
    context.succeed("haha11");
    callback(null,"Hello world!");
};

